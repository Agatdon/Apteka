﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Moderator
{
    public class PharamcyData
    {
        public bool IsChecked { get; set; }
        public string name_m { get; set; }
        public string substance { get; set; }
        public string form { get; set; }
        public string price { get; set; }

    }
}
